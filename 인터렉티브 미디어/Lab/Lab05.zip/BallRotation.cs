﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallRotation : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
    
    }
    //호출된 함수는 현재 게임 오브젝트의 회전각도를 표시합니다
    public void rotation()
    {
        //Vector3 rotation = transform.rotation;
        Debug.Log("rotation: " + gameObject.transform.rotation);
    }
}
