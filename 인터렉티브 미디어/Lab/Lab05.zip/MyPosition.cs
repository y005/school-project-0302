﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MyPosition : MonoBehaviour
{
    private int sec = 0;
    private BallRotation rotate;
    
    // Start is called before the first frame update
    void Start()
    {
        rotate = gameObject.AddComponent<BallRotation>();
    
    }

    // Update is called once per frame
    void Update()
    {
        rotate.rotation();
    }

    //0.02초마다 호출되는 함수로 50번 호출시 1초가 지난 시점으로 위치 호출을 한다.
    void FixedUpdate()
    {
        if (sec == 0)
        {
            Vector3 pos = transform.position;
            Debug.Log("pos: " + gameObject.transform.position);
        }
        sec = (sec + 1) % 50;
    }
}
