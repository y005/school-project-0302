﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveAndJump : MonoBehaviour
{
    //스폰위치를 위한 오브젝트
    public GameObject obj1;
    public GameObject obj2;
    private int time = 1500;//50프레임*30초 
    private int eatItem = 0;
   
    // Update is called once per frame
    void FixedUpdate()
    {
        //스페이스를 누른 경우 
        if (Input.GetKeyDown(KeyCode.Space))
        {
            GetComponent<Rigidbody>().AddForce(Vector3.up * 300f);
        }
        //좌우키에 따라 -1에서 1까지의 수를 반환하고
        //입력에 따라 좌우로 이동한다
        float h = Input.GetAxis("Horizontal");
        Vector3 horizontal = new Vector3(0, 0, 1);
        GetComponent<Transform>().Translate(-1*horizontal* h *Time.deltaTime*10);
        //30초가 지났는지 확인하기 위한 카운트
        time--;
    }


    void OnTriggerEnter(Collider other)
    {
        //포털을 지나면 해당 위치로 스폰
        if (other.gameObject.CompareTag("portal1"))
        {
            transform.position = obj1.transform.position;
        }
        if (other.gameObject.CompareTag("portal2"))
        {
            transform.position = obj2.transform.position;
        }
        //아이템과 충돌시 획득한 코인 횟수가 증가하고 해당 코인오브젝트를 삭제
        if (other.gameObject.CompareTag("item"))
        {
            eatItem++;
            Destroy(other.gameObject);
        }
        //마지막 목표에 도착한 경우
        //획득한 코인이 6개이고 시간 안에 도착한 경우 미션 성공을 출력
        if (other.gameObject.CompareTag("end"))
        {
            if ((eatItem == 6) && (time > -1))
            {
                Debug.Log("미션 성공");
            }
        }

    }
}
